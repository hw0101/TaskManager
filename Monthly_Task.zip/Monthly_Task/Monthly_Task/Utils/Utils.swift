//
//  Utils.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/7/1.
//

import Foundation

// 工具類
class Util {
    
    //JSON字符串轉為Dictionary
    class func getDictionaryFromJSONString(jsonString:String) -> NSDictionary {
     
        let jsonData:Data = jsonString.data(using: .utf8)!
     
        let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
        if dict != nil {
            return dict as! NSDictionary
        }
        return NSDictionary()
    }
    
    
    //JSON字符串轉為Array
    class func getArrayFromJSONString(jsonString:String) -> NSArray {
     
        let jsonData:Data = jsonString.data(using: .utf8)!
     
        let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
        if dict != nil {
            return dict as! NSArray
        }
        return NSArray()
    }
    
    
    //把Any類型轉String
    class func toString(_ value: Any?) -> String {
        return String(describing: value ?? "")
     }
    
    
    
}
