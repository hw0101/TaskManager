//
//  Type.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/2/23.
//

import Foundation

//用戶類
class User {
    
    //變量
    var user_id: String
    var name: String
   
    var position: String
    var user_grade: String

    //初始化
    init(user_id: String, name: String, position: String, user_grade: String) {
        self.user_id = user_id
        self.name = name
        self.position = position
        self.user_grade = user_grade
    }
    
}
