//
//  LoginViewController.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/2/24.
//

import UIKit

// 登陸介面
class LoginView: UIViewController, UITextFieldDelegate {

    //MARK:-連接控件
    //控件連接
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    //MARK:-變量設置
    static var login: Bool!
    static var loginedUserName: String!
    static var loginedUserGrade: String!
    static var userName: String!
    static var loginedUser: User = User.init(user_id: "", name: "", position: "", user_grade: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //設置textfield的delegate
        self.userNameTextField.delegate = self
        self.passwordTextField.delegate = self
        
        //設置textFieldSizeToFit
        self.userNameTextField.sizeToFit()
        self.passwordTextField.sizeToFit()
        
        //TextField初始值的設置
        self.userNameTextField.text = ""
        self.passwordTextField.text = ""
        
        //設置textfield為密碼模式
        self.passwordTextField.isSecureTextEntry = true
        
        //設置輸入框為圓角
        self.userNameTextField.borderStyle = UITextField.BorderStyle.roundedRect
        self.passwordTextField.borderStyle = UITextField.BorderStyle.roundedRect
        
        //設置masksToBounds為true
        self.userNameTextField.layer.masksToBounds = true
        self.passwordTextField.layer.masksToBounds = true
        
        //設置圓角半徑
        self.userNameTextField.layer.cornerRadius = 12.0
        self.passwordTextField.layer.cornerRadius = 12.0
       
        //設置邊框寬度
        self.userNameTextField.layer.borderWidth = 1.0
        self.passwordTextField.layer.borderWidth = 1.0
        
        //關閉translatesAutoresizingMaskIntoConstraints
        self.view.translatesAutoresizingMaskIntoConstraints = false
        self.userNameLabel.translatesAutoresizingMaskIntoConstraints = false
        self.passwordLabel.translatesAutoresizingMaskIntoConstraints = false
        self.userNameTextField.translatesAutoresizingMaskIntoConstraints = false
        self.passwordTextField.translatesAutoresizingMaskIntoConstraints = false
        self.loginButton.translatesAutoresizingMaskIntoConstraints = false
        
        //設置view的背景顏色
        self.view.backgroundColor = UIColor.systemBlue
        
        //給button添加action
        self.loginButton.addTarget(self, action: #selector(login), for: .touchUpInside)
    
        setLabelFontSize()
        setAutoLayout()
    }


    //設置Label字體大小
    func setLabelFontSize() {
        self.userNameLabel.font = UIFont.systemFont(ofSize: 20)
        self.passwordLabel.font = UIFont.systemFont(ofSize: 20)
    }
    

    func setAutoLayout() {
        //UserNameLabel
        self.userNameLabel.topAnchor.constraint(equalTo:self.view.topAnchor, constant: 80).isActive = true
        self.userNameLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30).isActive = true
        
        //PasswordLabel
        self.passwordLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 135).isActive = true
        self.passwordLabel.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 30).isActive = true
        
        //loginButton
        self.loginButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        self.loginButton.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 200).isActive = true
        
        //UserNameTextField
        self.userNameTextField.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 78).isActive = true
        self.userNameTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.userNameTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -30).isActive = true
        
        //PasswordNameTextField
        self.passwordTextField.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 135).isActive = true
        self.passwordTextField.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 120).isActive = true
        self.passwordTextField.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: -30).isActive = true
        
        
    }
    
    //MARK:-登陸函數
    //登錄函數
    @objc func login() {
        
        let userName = userNameTextField.text!
        let password = passwordTextField.text!
        
        //設置需要上傳到服務器的loginJSON數據
        let loginJSON: [String: String] = ["name": userName, "password": password]
                
                print("this is loginJsonFunction")
                print("this is post loginJSON Data",loginJSON)
               
                let jsonData = try? JSONSerialization.data(withJSONObject: loginJSON)

                //設置url地址
                let url = URL(string: "http://192.168.31.22:8082/login")!
                       
               //let url = URL(string: "http://192.168.31.35:8082/login")!
       
                //設置request請求
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                //將json插入請求
                request.httpBody = jsonData
                
                //傳輸數據並且處理返回數據
                let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
                    guard let data = data, error == nil else {
                        print(error?.localizedDescription ?? "No data")
                        return
                    }
                    
                    //接收返回的數據
                    let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
                    
                    //打印出返回的JSON數據
                    print("this is responsJSON",responseJSON)
            
                    var responseJSONData: [String: Any]
                   
                    //將返回的JSON數據轉換為[String: Any]類型
                    if let responseJSONData = responseJSON as? [String: Any] {
                     
                        //打印轉換後的[String: Any]字典
                        print("this is the resonseJSONData",responseJSONData)
                        
                        //取出字典中state的值
                        let stateString = Util.toString(responseJSONData["state"])
                        //取出字典中data的值
                        let userJSONData = responseJSONData["data"]
                        
                        //將userJSONData轉換為字典
                        //let userDataDictionary = getDictionaryFromJSONString(jsonString: userJSONData as! String)
                        let userDataDictionary = Util.getDictionaryFromJSONString(jsonString: userJSONData as! String)
                        
                        print("this is userDataDictionary",userDataDictionary)
                        
                        //分別取出其中name、position、gradeofData的值
                        let name = Util.toString(userDataDictionary["name"])
                        let position = Util.toString(userDataDictionary["position"])
                        let gradeofData = Util.toString(userDataDictionary["user_grade"])
                        let idOfData = Util.toString(userDataDictionary["user_id"])
                        
                        //let loginUserName = toString(userDataDictionary["name"])
                        let loginUserName = name
                        print("this is loginUserName",loginUserName)
                                                
                        let stateValue = Int(stateString)!
                        
                        //根據stateValue判斷登陸是否成功，如果登陸成功，跳到TabController，如果登陸失敗，提示重新輸入登錄
                        if (stateValue >= 0) {
                            showTabController()
                            //添加信息到loginUser
                            DispatchQueue.main.async {
                               
                                LoginView.loginedUser.name = name
                                LoginView.loginedUser.user_id = idOfData

                                LoginView.loginedUserName = name
                                print("this is loginuser name",LoginView.loginedUserName)
                                
                                LoginView.loginedUserGrade = gradeofData
                                print("this is loginedUserGrade", LoginView.loginedUserGrade)
                                    
                                print("this is loginedUser.name", LoginView.loginedUser.name)
                                print("this is loginedUser.user_id", LoginView.loginedUser.user_id)
                            }
                        } else if (stateValue < 0) {
                            showAlert()
                       }
                 }
           }
           task.resume()
     }
        
    //MARK:-提示框以及
    //顯示警告提示框函數
    func showAlert() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "提醒", message: "請輸入正確的用戶名和密碼", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: false, completion: nil)
        }
    }
    
    //跳轉顯示TabbarController函數
    func showTabController() {
        DispatchQueue.main.async {
            let vc = TabBarController()
            self.present(vc, animated: true, completion: nil)
        }
    }
}
