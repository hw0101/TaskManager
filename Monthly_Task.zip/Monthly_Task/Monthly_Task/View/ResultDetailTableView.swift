//
//  ResultDetailTableView.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/7/13.
//

import UIKit

//任務詳情列表
class ResultDetailTableView: UITableViewController {
        
    //MARK: -變量設置
    var sectionTitle = ["发送者","接收者","项目ID","项目名称","功能模块","计划用时","实际用时","分项评级","备注","月度评价","接收者同意(点击进行确认)", "发布者同意(点击进行确认)"]
    static var dataArray = [String](repeating: "", count: 12)
    var taskId: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.reloadData()
        self.title = "项目详情"
        self.tableView.delegate = self
        self.tableView.dataSource = self 
    }
    
    //MARK:-TableViewDelegate和DataSource的設置
    //設置Section數目
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return self.sectionTitle.count

    }
    
    //設置每個section有多少行
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }

    //设置tableView每个部分的Header的高
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
           return 30
    }

    //设置tableView每个部分Header内容
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
           let view = UIView()
           view.backgroundColor = UIColor(red:0.94, green:0.94, blue:0.94, alpha:1.0)
             // view.backgroundColor = UIColor.systemBlue
           let viewLabel = UILabel(frame: CGRect(x: 10, y: 0, width: UIScreen.main.bounds.size.width, height: 30))
               //viewLabel.text = data[section].0
           viewLabel.text = sectionTitle[section]
              // viewLabel.textColor = UIColor(red:0.31, green:0.31, blue:0.31, alpha:1.0)
           viewLabel.textColor = UIColor.black
           view.addSubview(viewLabel)
           tableView.addSubview(view)
           return view
    }
    
    //設置cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let identifier = "reusedCell"
          var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
    
          if (cell == nil) {
             cell = UITableViewCell(style: .default, reuseIdentifier: identifier)
          }

         cell?.backgroundColor = UIColor.systemBlue
         let rowNum = (indexPath as NSIndexPath).section
         cell?.textLabel?.text = ResultDetailTableView.dataArray[rowNum]
         return cell!
    }
    
    //tableView選定特定的行反饋
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
        print("this is indexPath.row", indexPath.row)
        print("this is indexPath.section", indexPath.section)
        
        if ((indexPath.section == 10) && (indexPath.row == 0)) {
            showAccepterConfirmAlert()
        }
        
        if ((indexPath.section == 11) && (indexPath.row == 0)) {
            showPromulgatorConfirmAlert()
            promulgatorConsent()
        }
    }
    
    //MARK:-提示框
    //顯示接受者同意提示框
    func showAccepterConfirmAlert() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "😺接受者同意", message: "点击同意接收任务", preferredStyle: UIAlertController.Style.alert)
            let action = UIAlertAction.init(title: "接收任务", style: .default) { (UIAlertController) in
            self.tableView.cellForRow(at: IndexPath(row: 0, section: 10))?.textLabel?.text = "是"
                   
            //更新接受者同意狀態（傳送到服務器）
            self.accepterConsent()
            SearchTaskTwoView.task[SearchResultTableView.selectedRow].accepter_consent = "1"

        }
            alert.addAction(action)
            self.present(alert, animated: false, completion: nil)
        }
    }
    
    //顯示發布者同意提示框
    func showPromulgatorConfirmAlert() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "😺发布者同意", message: "点击确认任务完成", preferredStyle: UIAlertController.Style.alert)
            let action = UIAlertAction.init(title: "确认任务完成", style: .default) { (UIAlertController) in
            self.tableView.cellForRow(at: IndexPath(row: 0, section: 11))?.textLabel?.text = "是"
                DispatchQueue.main.async {
                    ResultDetailTableView.dataArray[11] = "是"
                    self.tableView.reloadData()
                }
                    self.promulgatorConsent()
            }
                    alert.addAction(action)
                    self.present(alert, animated: false, completion: nil)
            }
    }
    
    //MARK:-TableView內功能函數
    //發布者同意同步函數
    func accepterConsent() {
        
        let task_id = ResultDetailTableView.dataArray[2]
        let accepter_consent = "1"
       
        print("this is accepterConsent")
        
        //定義JSON數據
        let consentJSON: [String: Any] = [ "task_id": task_id,
                                           "accepter_consent": accepter_consent
                                         ]
           
        let jsonData = try? JSONSerialization.data(withJSONObject: consentJSON)

        //設置url地址
        //線上地址
        let url = URL(string: "http://192.168.31.22:8082/TaskAccepterConsent")!
        
        //本地
        // let url = URL(string: "http://192.168.31.35:8082/addTask")!

        //設置request請求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //將JSON插入請求
        request.httpBody = jsonData
        
        //傳輸數據並且處理返回數據
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            //接收返回的數據
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            
            //打印出返回的JSON數據
            print("this is responsJSON",responseJSON)
    
            var responseJSONData: [String: Any]
            //將返回的JSON數據轉換為[String: Any]類型
            if let responseJSONData = responseJSON as? [String: Any] {
             
                //打印轉換後的[String: Any]字典
                print("this is the resonseJSONData",responseJSONData)
                
                //取出[String: Any]字典中data的值
                let individualJSONData = responseJSONData["data"]
                
                //取出[String: Any]字典中的state的值
                let stateString = Util.toString(responseJSONData["state"])
                let stateValue = Int(stateString)!
                
            }
        }
        task.resume()
    }
    
    //發布者同意同步函數
    func promulgatorConsent() {
        
        //設置JSON數據源
        let task_id = ResultDetailTableView.dataArray[2]
        let accepter_consent = "1"
       
        print("this is accepterConsent")
        
        //定義json數據
        let consentJSON: [String: Any] = [ "task_id": task_id,
                                           "accepter_consent": accepter_consent
                                         ]
           
        let jsonData = try? JSONSerialization.data(withJSONObject: consentJSON)

        //設置url地址
        //線上地址
        let url = URL(string: "http://192.168.31.22:8082/TaskAccepterConsent")!
        
        //本地
        // let url = URL(string: "http://192.168.31.35:8082/addTask")!

        //設置request請求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //將json插入請求
        request.httpBody = jsonData
        
        //傳輸數據並且處理返回數據
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            guard let data = data, error == nil else {
                  print(error?.localizedDescription ?? "No data")
                  return
            }
            
            //接收返回的數據
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            //打印出返回的JSON數據
            print("this is responsJSON",responseJSON)
    
            var responseJSONData: [String: Any]
            //將返回的JSON數據轉換為[String: Any]類型
            if let responseJSONData = responseJSON as? [String: Any] {
             
                //打印轉換後的[String: Any]字典
                print("this is the resonseJSONData",responseJSONData)
                
                //取出[String: Any]字典中data的值
                let individualJSONData = responseJSONData["data"]
                
                //取出[String: Any]字典中的state的值
                let stateString = Util.toString(responseJSONData["state"])
                let stateValue = Int(stateString)!
            }
        }
        task.resume()
    }
}
    
    
    
    
    


