//
//  UserListTableView.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/5/24.
//

import UIKit

class UserListTableView: UITableViewController {

    //MARK:-變量設置
    static var nameList: [String]! = []
    static var positionList: [String]! = []
    static var gradeList: [String]! = []
    static var idList: [String]! = []
    static var user: [User]! = []
    static var idName: [String: String]! = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //設置tableView的delegate和dataSource
        self.tableView.delegate = self
        self.tableView.dataSource = self
       
        //設置tableView userInteractionEnabled為false
        self.tableView.isUserInteractionEnabled = false
        
        //获取用户列表
        getUserList()
        
        //设置用户title
        self.title = "用户列表"
        
        //设置背景颜色
        self.view.backgroundColor = UIColor.systemBlue
        print("this is nameList from viewdidload", UserListTableView.nameList)
    }
  
    //獲取用戶列表
    func getUserList() {
       
        print("this is getuserList function")
       
        //設置Json數據
        let json: [String: Any] = ["":""]
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        //設置url地址
        let url = URL(string: "http://192.168.31.22:8082/userList")!
               
        //設置request請求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //將json插入請求
        request.httpBody = jsonData
        
        //傳輸數據並且處理返回數據
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            //接收返回的數據
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            //打印出返回的JSON數據
            print("this is responsJSON",responseJSON)
    
            var responseJSONData: [String: Any]
            //將返回的JSON數據轉換為[String: Any]類型
            if let responseJSONData = responseJSON as? [String: Any] {
             
                //打印轉換後的[String: Any]字典
                print("this is the resonseJSONData",responseJSONData)
                
                //取出[String: Any]字典中data的值
                let resultJSONData = responseJSONData["data"]
            
                //打印出individualJSONData的值（為JSON數據）
                print("This is resultJSONData from resultJSONData",resultJSONData)
                
                //let resultArray = getArrayFromJSONString(jsonString: individualJSONData as! String)
                
                //將Any類型轉換為Array
                let resultArray = Util.getArrayFromJSONString(jsonString: resultJSONData as! String)
                
                print("this is resultArray", resultArray)
                print("this is resultArray[0]", resultArray[0])
                
                //將數組中的值轉換為字典並且賦予相應的變量和類
                for i in 0...resultArray.count-1 {

                        let data = resultArray[i] as! [String: Any]
                  
                        let nameOfData = data["name"]
                        let positionOfData = data["position"]
                        let gradeOfData = data["user_grade"]
                        let idOfData = data["user_id"]
                    
                        let name = Util.toString(nameOfData)
                        let position = Util.toString(positionOfData)
                        let grade = Util.toString(gradeOfData)
                        let id = Util.toString(idOfData)
                    
                        UserListTableView.idName!.updateValue(name, forKey: id)
                        UserListTableView.nameList.append(name)
                        UserListTableView.positionList.append(position)
                        UserListTableView.gradeList.append(grade)
                        UserListTableView.idList.append(id)
                        
                        //將值賦予user[User]的元素
                        UserListTableView.user.append(User.init(user_id: id, name: name, position: position, user_grade: grade))
                }
            }
        }
        task.resume()
    }
    
    //MARK:-TableView Delegate 和 DataSource設置
    // 设置Section数目
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    //設置tableView
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UserListTableView.nameList.count
    }
    
    //設置cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = "reusedCell"
        var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
        cell?.backgroundColor = UIColor.systemBlue
        cell?.textLabel?.textColor = UIColor.black
        
        if (cell == nil) {
            cell = UITableViewCell(style: .default, reuseIdentifier: identifier)
            cell?.backgroundColor = UIColor.systemBlue
        }
        cell?.textLabel?.text = UserListTableView.nameList![indexPath.row] + "  " + UserListTableView.positionList![indexPath.row] + "  等级" + UserListTableView.gradeList![indexPath.row] + "   ID" + UserListTableView.idList![indexPath.row]

        return cell!
    }
}
    
    
    
    
    
