//
//  SearchResultTableView.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/7/8.
//

import UIKit

//搜索詳情結果列表界面
class SearchResultTableView: UITableViewController {
        
    //MARK:-變量設置
    static var selectedRow: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //設置View的標題
        self.title = "搜索结果"
        
        //頁面navigationBar的相關設置
        self.navigationItem.leftItemsSupplementBackButton = true
        self.navigationController?.navigationBar.tintColor = UIColor.white
         
        //tableView數據reloadData
        self.tableView.reloadData()
        
        //設置tableView的delegate和dataSource
        self.tableView.dataSource = self
        self.tableView.delegate = self
       
        //設置tableView的背景顏色
        self.tableView.backgroundColor = UIColor.systemBlue
        print("in tableview",SearchTaskTwoView.task.count)
    }
        
    //MARK:-Table view Delegate和 Data source
    //設置section數目
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    //設置每個Section row的數目
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return SearchTaskTwoView.task.count
    }
    
    //設置seciton的title
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "项目名称"
    }

    //設置HeaderView
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        if let header = view as? UITableViewHeaderFooterView {
            header.backgroundView?.backgroundColor = UIColor.white
            header.textLabel!.font = UIFont.systemFont(ofSize: 18)
            header.textLabel!.textColor = UIColor.black
        }
    }
    
    //設置cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let identifier = "reusedCell"
        var cell = tableView.dequeueReusableCell(withIdentifier: identifier)
    
        if (cell == nil) {
            cell = UITableViewCell(style: .default, reuseIdentifier: identifier)
        }
        cell?.accessoryType = .disclosureIndicator
        cell?.backgroundColor = UIColor.systemBlue
        cell?.textLabel?.text = SearchTaskTwoView.task[indexPath.row].project
    
        return cell!
    }
 
    //設置點擊cell跳轉到ResultDatailTableView
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        SearchResultTableView.selectedRow = indexPath.row
        print("this is selectedRow",SearchResultTableView.selectedRow)
        ResultDetailTableView.dataArray[0] = UserListTableView.idName![SearchTaskTwoView.task[indexPath.row].promulgator]!
        ResultDetailTableView.dataArray[1] = UserListTableView.idName![SearchTaskTwoView.task[indexPath.row].accepter]!
        ResultDetailTableView.dataArray[2] = SearchTaskTwoView.task[indexPath.row].task_id
        ResultDetailTableView.dataArray[3] = SearchTaskTwoView.task[indexPath.row].project
        ResultDetailTableView.dataArray[4] = SearchTaskTwoView.task[indexPath.row].function_module
        ResultDetailTableView.dataArray[5] = SearchTaskTwoView.task[indexPath.row].plan_time
        ResultDetailTableView.dataArray[6] = SearchTaskTwoView.task[indexPath.row].practical_time
        ResultDetailTableView.dataArray[7] = SearchTaskTwoView.task[indexPath.row].subentry_evaluate
        ResultDetailTableView.dataArray[8] = SearchTaskTwoView.task[indexPath.row].remark
        ResultDetailTableView.dataArray[9] = SearchTaskTwoView.task[indexPath.row].monthly_evaluate
        ResultDetailTableView.dataArray[10] = (Int(SearchTaskTwoView.task[indexPath.row].accepter_consent)! > 0) ? "是":"否"
        ResultDetailTableView.dataArray[11] = (Int(SearchTaskTwoView.task[indexPath.row].promulgator_consent)! > 0) ? "是":"否"
        self.navigationController?.pushViewController(ResultDetailTableView(), animated: false)
    }
}
