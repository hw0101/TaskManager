//
//  SearchTaskTwoView.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/6/28.
//

import UIKit


//搜索任務
class SearchTaskTwoView: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //MARK:-連接控件
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var dataSourceLabel: UILabel!
    
    @IBOutlet weak var yearButton: UIButton!
    @IBOutlet weak var monthButton: UIButton!
    @IBOutlet weak var dataSourceButton: UIButton!
    @IBOutlet weak var submitButton: UIButton!

    @IBOutlet weak var selectPickerView: UIPickerView!
    
    @IBOutlet weak var selectPickerViewToolbar: UIToolbar!
    @IBOutlet weak var confirmButton: UIBarButtonItem!
    @IBOutlet weak var selectPickerViewToolbarSpace: UIBarButtonItem!
    @IBOutlet weak var cancelButton: UIBarButtonItem!
    
    //MARK:-變量設置
    static var task: [Task]! = []
    static var nameList: [String] = ["任意"]
    static var idList: [String] = ["任意"]
    
    var dataSource = ["我发布的", "我接受的"]
    var yearData = ["2022", "2023", "2024", "2025", "2026", "2027", "2028"]
    var monthData = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]

    var selectedRow: Int!
    var selectedText: String!
    var tempArr = [String]()
    var selectedBtn = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //獲取用戶列表
        SearchTaskTwoView.getUserList()
        
        //設置View標題
        self.title = "搜索任务"
        
        //添加控件到view
        self.view.addSubview(selectPickerView)
        self.view.addSubview(yearLabel)
        self.view.addSubview(monthLabel)
        self.view.addSubview(dataSourceLabel)
        
        self.view.addSubview(dataSourceButton)
        self.view.addSubview(yearButton)
        self.view.addSubview(monthButton)
     
        self.view.addSubview(selectPickerView)
        self.view.addSubview(selectPickerViewToolbar)
        
        self.view.addSubview(submitButton)
        
        //關閉各個view的autoresize
        self.yearLabel.translatesAutoresizingMaskIntoConstraints = false
        self.monthLabel.translatesAutoresizingMaskIntoConstraints = false
        self.dataSourceLabel.translatesAutoresizingMaskIntoConstraints = false
        self.yearButton.translatesAutoresizingMaskIntoConstraints = false
        self.monthButton.translatesAutoresizingMaskIntoConstraints = false
        self.submitButton.translatesAutoresizingMaskIntoConstraints = false
        self.dataSourceButton.translatesAutoresizingMaskIntoConstraints = false
        self.selectPickerView.translatesAutoresizingMaskIntoConstraints = false
        self.selectPickerViewToolbar.translatesAutoresizingMaskIntoConstraints = false
        
        //設置Button
        self.dataSourceButton.titleLabel?.textAlignment = .center
        self.yearButton.titleLabel?.textAlignment = .center
        self.monthButton.titleLabel?.textAlignment = .center
        
        //設置圓角
        self.dataSourceButton.layer.cornerRadius = 12
        self.yearButton.layer.cornerRadius = 12
        self.monthButton.layer.cornerRadius = 12
        
        self.dataSourceButton.layer.borderWidth = 1
        self.yearButton.layer.borderWidth = 1
        self.monthButton.layer.borderWidth = 1
        
        //設置Button
        self.dataSourceButton.layer.borderColor = UIColor.black.cgColor
        self.yearButton.layer.borderColor = UIColor.black.cgColor
        self.monthButton.layer.borderColor = UIColor.black.cgColor
        
        //設置pickerView
        self.selectPickerView.isHidden = true
        self.selectPickerViewToolbar.isHidden = true
        self.selectPickerView.delegate = self
        self.selectPickerView.dataSource = self
   
        //設置toolbar
        self.selectPickerViewToolbar.setItems([confirmButton,selectPickerViewToolbarSpace,cancelButton], animated: false)
        self.selectPickerViewToolbar.sizeToFit()
        self.selectPickerView.inputAccessoryView?.addSubview(selectPickerViewToolbar)

        //設置toolbar按鈕
        let font: UIFont = UIFont.systemFont(ofSize: 22.0)
        let textAttributes: [NSAttributedString.Key: Any] = [.font: font]
        
        self.cancelButton.setTitleTextAttributes(textAttributes, for: .normal)

        //PickerView ToolBar Button設置按鈕功能
        self.confirmButton.action = #selector(confirm)
        self.cancelButton.action = #selector(cancel)
        
        //view背景設置
        self.view.backgroundColor = UIColor.systemBlue
        
        //設置提交按鈕函數
        self.submitButton.addTarget(self, action: #selector(searchTask), for: .touchUpInside)
        
    }
   
    func setAutoLayout() {
        
    }
    
    
    
    // 設置選擇按鈕按下反饋功能（設置pickerView數據源）
    @IBAction func ButtonActions(_ sender: UIButton) {
        selectedBtn = sender
        if (sender == dataSourceButton) {
            tempArr = dataSource
        } else if (sender == yearButton) {
            tempArr = yearData
        } else if (sender == monthButton) {
            tempArr = monthData
        }
        self.selectPickerView.reloadAllComponents()
        self.selectPickerView.isHidden = false
        self.selectPickerViewToolbar.isHidden = false
    }
    
    
   //獲取用戶列表
   class func getUserList() {
        print("this is getuserList function")
       
        //設置Json數據
        let json: [String: Any] = ["":""]
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        //設置url地址
        let url = URL(string: "http://192.168.31.22:8082/userList")!
               
        //設置request請求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //將json插入請求
        request.httpBody = jsonData
        
        //傳輸數據並且處理返回數據
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            //接收返回的數據
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            //打印出返回的JSON數據
            print("this is responsJSON",responseJSON)
    
            var responseJSONData: [String: Any]
            //將返回的JSON數據轉換為[String: Any]類型
            if let responseJSONData = responseJSON as? [String: Any] {
             
                //打印轉換後的[String: Any]字典
                print("this is the resonseJSONData",responseJSONData)
                
                //取出[String: Any]字典中data的值
                let userJSONData = responseJSONData["data"]
                //打印出individualJSONData的值（為JSON數據）
                print("This is individualJSONData from postPersonalData",userJSONData)
                
                
                let resultArray = Util.getArrayFromJSONString(jsonString: userJSONData as! String)
                print("this is resultArray", resultArray)
                print("this is resultArray[0]", resultArray[0])
                
                for i in 0...resultArray.count-1 {

                        let data = resultArray[i] as! [String: Any]
                        let nameOfData = data["name"]
                        let idOfData = data["user_id"]
                        SearchTaskTwoView.nameList.append(Util.toString(nameOfData))
                        SearchTaskTwoView.idList.append(Util.toString(idOfData))
                }
            }
        }
        task.resume()
    }
    
    //MARK:-搜索函數
    @objc func searchTask() {

        if ((self.dataSourceButton.titleLabel?.text == "请选择数据来源") || (self.yearButton.titleLabel?.text == "请选择年份") || (self.monthButton.titleLabel?.text == "请选择月份")) {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "😺提醒", message: "请亲选择数据来源、年份、月份三者", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: false, completion: nil)
            }
        }
        
        if ((self.dataSourceButton.titleLabel?.text != "请选择数据来源") && (self.yearButton.titleLabel?.text != "请选择年份") && (self.monthButton.titleLabel?.text != "请选择月份")) {
            DispatchQueue.main.async {
                self.searchJsonTask()
            }
        }
    }

    //JSON上傳函數
    @objc func searchJsonTask() {
        
        SearchTaskTwoView.task.removeAll()
        
        let promulgator = LoginView.loginedUser.user_id
        let accepter = LoginView.loginedUser.user_id
        let year = yearButton.titleLabel?.text
        let monthString = monthButton.titleLabel?.text
        let month = (Int(monthString!)! < 10) ? ("0" + monthString!) : (monthString!)
        var searchJson: [String: Any] = [:]
        
        if (self.dataSourceButton.titleLabel?.text == "我接受的") {
                searchJson = [ "accepter": accepter, "time": year! + "-" + month]
        } else if (self.dataSourceButton.titleLabel?.text == "我发布的") {
                searchJson = [ "promulgator": accepter, "time": year! + "-" + month]
        }
                        
        print("this is searchJSON", searchJson)
        
        let jsonData = try? JSONSerialization.data(withJSONObject: searchJson)

        //設置url地址
        let url = URL(string: "http://192.168.31.22:8082/conditionQueryTask")!

        //let url = URL(string: "http://192.168.31.35:8082/conditionQueryTask")!

        //設置request請求
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("\(String(describing: jsonData?.count))", forHTTPHeaderField: "Content-Length")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        //將json插入請求
        request.httpBody = jsonData
        
        //傳輸數據並且處理返回數據
        let task = URLSession.shared.dataTask(with: request) { [self] data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            
            //接收返回的數據
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            //打印出返回的JSON數據
            print("this is responsJSON",responseJSON)
    
            var responseJSONData: [String: Any]
            //將返回的JSON數據轉換為[String: Any]類型
            if let responseJSONData = responseJSON as? [String: Any] {
             
                //打印轉換後的[String: Any]字典
                print("this is the resonseJSONData",responseJSONData)
                
                //取出[String: Any]字典中state的值
                let stateString = Util.toString(responseJSONData["state"])
                let stateValue = Int(stateString)!
                
                if (stateValue > 0) {
                    
                    //取出[String: Any]字典中data的值
                    let resultJSONData = responseJSONData["data"]
                    print("this is the resultJSONData", resultJSONData)
                    
                    //轉換成數組
                    let resultJSONArray = Util.getArrayFromJSONString(jsonString: resultJSONData as! String)
                    print("this is resultJSONArray",resultJSONArray)
                     
                    for i in 0...resultJSONArray.count-1 {
                    
                           //取出數組[1]的值
                          let resultJSONArrayOne = resultJSONArray[i] as! [String: Any]
                    
                          print("this is resultJSONArrayOne", resultJSONArrayOne)
                        
                          let time = Util.toString(resultJSONArrayOne["time"])
                          let accepter = Util.toString(resultJSONArrayOne["accepter"])
                          let accepter_consent = Util.toString(resultJSONArrayOne["accepter_consent"])
                          let promulgator_consent = Util.toString(resultJSONArrayOne["promulgator_consent"])
                          let task_id = Util.toString(resultJSONArrayOne["task_id"])
                          let promulgator = Util.toString(resultJSONArrayOne["promulgator"])
                        
                          //取出字典中Content的值，並最終轉換為字典
                          let content = resultJSONArrayOne["content"]
                          print("this is content",content)
                          let contentArray = Util.getArrayFromJSONString(jsonString: content as! String)
                          print("this is contentArray", contentArray)
                          let contentArrayOne = contentArray[0]
                          print("this is cotentArrayOne", contentArrayOne)
                          let contentArrayOneDic = contentArrayOne as! [String:Any]
                          print("this is contentArrayOneDic", contentArrayOneDic)
                    
                          //獲取類中的數值
                          let remark = Util.toString(contentArrayOneDic["remark"])
                          let function_module = Util.toString(contentArrayOneDic["function_module"])
                          let monthly_evaluate = Util.toString(contentArrayOneDic["monthly_evaluate"])
                          let subentry_evaluate = Util.toString(contentArrayOneDic["subentry_evaluate"])
                          let project = Util.toString(contentArrayOneDic["project"])
                          let plan_time = Util.toString(contentArrayOneDic["plan_time"])
                          let practical_time = Util.toString(contentArrayOneDic["practical_time"])
                      
                          //task數組添加成員
                          SearchTaskTwoView.task.append(Task.init(promulgator: promulgator, accepter: accepter, time: time, task_id: task_id, project: project, function_module: function_module, plan_time: plan_time, practical_time: practical_time, subentry_evaluate: subentry_evaluate, remark: remark, monthly_evaluate: monthly_evaluate, promulgator_content: promulgator_consent, accepter_consent: accepter_consent))
                    }
                    print(SearchTaskTwoView.task.count)
                    
                    //成功顯示成功提示框
                    showSucceedAlert()
               } else if (stateValue < 0) {
                    //失敗顯示失敗提示框
                    showFailAlert()
               }
            }
        }
        task.resume()
    }
    
    //MARK:-提示框設定
    //成功提示框
    func showSucceedAlert() {
        DispatchQueue.main.async {
               let alert = UIAlertController(title: "😺提醒", message: "搜索到相关数据，点击确认查看", preferredStyle: UIAlertController.Style.alert)
               let action = UIAlertAction.init(title: "确认", style: .default) { (UIAlertController) in
               let vc = SearchResultTableView()
               self.navigationController?.pushViewController(vc, animated: false)
            }
            alert.addAction(action)
            self.present(alert, animated: false, completion: nil)
        }
    }

    //失敗提示框
    func showFailAlert() {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "😺提醒", message: "无相关数据", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "确认", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: false, completion: nil)
        }
    }
    
    //MARK:-pickerView Delegate 和 DataSouce 設置 以及相關函數
    //設置pickerview數據列數
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    //設置pickerview每列數據行數
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return tempArr.count
    }
    
    //設置pickerview每行的數據
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return tempArr[row]
    }
    
    //設置點擊頁面後pickerview隱藏
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.selectPickerView.isHidden = true
        self.selectPickerViewToolbar.isHidden = true 
    }
    
    // 确认功能（确认pickerview数据）
    @objc func confirm() {
       // selectedBtn.setTitle(selectedText, for: .normal)
        
        let selectedRow = selectPickerView.selectedRow(inComponent: 0)
        self.selectedBtn.setTitle(tempArr[selectedRow], for: .normal)
        
       //print(selectedBtn.titleLabel?.text)
        self.selectPickerView.isHidden = true
        self.selectPickerViewToolbar.isHidden = true
        
    }
    
    // 取消功能（关闭pickerView）
    @objc func cancel() {
        self.selectPickerView.isHidden = true
        self.selectPickerViewToolbar.isHidden = true
    }
}


//[{"accepter":12,"accepter_consent":0,"content":"[{\"practical_time\":\"\",\"function_module\":\"1\",\"plan_time\":\"1\",\"project\":\"1\",\"subentry_evaluate\":\"\",\"remark\":\"\",\"monthly_evaluate\":\"\"}]","promulgator":13,"promulgator_consent":0,"task_id":139,"time":"2022-07-06 09:52:51"},{"accepter":12,"accepter_consent":0,"content":"[{\"practical_time\":\"\",\"function_module\":\"ak47\",\"plan_time\":\"\",\"project\":\"cs\",\"monthly_evaluate\":\"\",\"remark\":\"\",\"subentry_evaluate\":\"\"}]","promulgator":13,"promulgator_consent":0,"task_id":140,"time":"2022-07-06 11:43:32"},{"accepter":12,"accepter_consent":0,"content":"[{\"practical_time\":\"\",\"function_module\":\"ak47\",\"plan_time\":\"\",\"project\":\"cs\",\"monthly_evaluate\":\"\",\"remark\":\"\",\"subentry_evaluate\":\"\"}]","promulgator":13,"promulgator_consent":0,"task_id":141,"time":"2022-07-06 11:43:44"},{"accepter":12,"accepter_consent":0,"content":"[{\"practical_time\":\"\",\"plan_time\":\"\",\"function_module\":\"m4\",\"project\":\"cs\",\"remark\":\"\",\"subentry_evaluate\":\"\",\"monthly_evaluate\":\"\"}]","promulgator":13,"promulgator_consent":0,"task_id":142,"time":"2022-07-06 11:49:37"},{"accepter":12,"accepter_consent":0,"content":"[{\"practical_time\":\"\",\"function_module\":\"mp5\",\"plan_time\":\"\",\"project\":\"cs\",\"subentry_evaluate\":\"\",\"remark\":\"\",\"monthly_evaluate\":\"\"}]","promulgator":13,"promulgator_consent":0,"task_id":143,"time":"2022-07-06 11:51:39"}]
//
//
//[{"name":"袁俊峰","user_grade":10,"user_id":5},{"name":"陈龙","position":"java开发工程师","user_grade":1,"user_id":7},{"name":"孙泽涛","position":"ios开发工程师","user_grade":1,"user_id":9},{"name":"demo","position":"开发","user_grade":1,"user_id":12},{"name":"demo2","position":"开发","user_grade":1,"user_id":13}]
