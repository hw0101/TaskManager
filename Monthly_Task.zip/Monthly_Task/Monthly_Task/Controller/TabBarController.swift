//
//  TabBarController.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/2/23.
//

import UIKit

//TabBarController
class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //導航NavigationController設置
        let navControllerOne = NavigationController(rootViewController: PostTaskView())
        let navControllerTwo = NavigationController(rootViewController: SearchTaskTwoView())
        let navControllerThree = NavigationController(rootViewController: SearchResultTableView())
        let navControllerSeven = NavigationController(rootViewController: ResultDetailTableView())
       
        //設置UITabBar Item的選中與未選中顏色的變化
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.black], for: .selected)
      
        //設置tabBarController的頁面
        //self.viewControllers = [navControllerOne,navControllerTwo,navControllerThree,navControllerSeven]
        self.viewControllers = [navControllerOne,navControllerTwo,navControllerSeven]

        
        //設置tabBarController默認選中頁面
        self.selectedIndex = 0
        
        //設置tabBarController各item的標題
        navControllerOne.tabBarItem.title = "发布任务"
        navControllerTwo.tabBarItem.title = "搜索任务"
        navControllerThree.tabBarItem.title = "搜索结果"
        
        //設置各tabBarItem的圖標
        navControllerOne.tabBarItem.image = UIImage(named: "posttask")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        navControllerTwo.tabBarItem.image = UIImage(named: "search")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        navControllerThree.tabBarItem.image = UIImage(named: "result")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal)
        
        //設置tabBarController的背景顏色
        self.tabBar.barTintColor = UIColor.blue
    }
}
