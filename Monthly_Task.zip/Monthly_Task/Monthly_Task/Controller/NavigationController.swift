//
//  NavigationController.swift
//  Monthly_Task
//
//  Created by mickeytora on 2022/2/23.
//

import UIKit

//導航Controller
class NavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
    
        //navigationBar不透明
        self.navigationBar.isTranslucent = false
        
        //navigaitonBar欄的背景顏色
        self.navigationBar.barTintColor = UIColor.blue
       
        //設置navigationBar字體顏色
        self.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
    }
     
    
    
}
